package org.spring.Team_project_1;

import org.junit.jupiter.api.Test;
import org.spring.Team_project_1.entity.MemberEntity;
import org.spring.Team_project_1.entity.ShopEntity;
import org.spring.Team_project_1.member.MemberDto;
import org.spring.Team_project_1.member.MemberRepository;
import org.spring.Team_project_1.member.MemberService;
import org.spring.Team_project_1.role.Role;
import org.spring.Team_project_1.shop.ShopDto;
import org.spring.Team_project_1.shop.ShopRepository;
import org.spring.Team_project_1.shop.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.io.IOException;


public class memberTest {

}
