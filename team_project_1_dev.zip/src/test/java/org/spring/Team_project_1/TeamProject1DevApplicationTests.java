package org.spring.Team_project_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class TeamProject1DevApplicationTests {

}
