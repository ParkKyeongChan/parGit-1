function homeFn() {
location.href = '/index';
}

function backFn() {
history.back();
}