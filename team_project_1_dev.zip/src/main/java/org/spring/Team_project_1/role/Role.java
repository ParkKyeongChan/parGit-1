package org.spring.Team_project_1.role;

public enum Role {
    MEMBER, SELLER, ADMIN
}
