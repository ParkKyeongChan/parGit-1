package org.spring.Team_project_1.file.fileServiceImpl;


public interface FileServiceImpl {


}
