package org.spring.Team_project_1.file;

import org.spring.Team_project_1.file.fileServiceImpl.FileServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class FileService implements FileServiceImpl {


}
